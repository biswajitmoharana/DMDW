# Data-Mining-and-Data-Warehousing
Hello there, i am doing some lab assignments regarding to Data Mining and Data Warehoushing
